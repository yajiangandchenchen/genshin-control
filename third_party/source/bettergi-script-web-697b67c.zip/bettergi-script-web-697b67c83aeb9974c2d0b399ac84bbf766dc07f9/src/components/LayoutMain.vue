<template>
  <a-layout class="main-layout">
    <!-- 左侧菜单 -->
    <div class="custom-sider">
      <div class="sider-header">
        <div class="sider-logo"
             :title="$t('sider.document')"
             @click="mainStore.openExternalLink('https://www.bettergi.com/')"
        >
        </div>
        <span class="repo-title">{{ $t('sider.repoTitle') }}</span>
      </div>
      <div class="sider-menu-wrap">
        <div class="menu-content">
          <a-menu v-model:selectedKeys="mainStore.selectedMenu"
                  mode="vertical"
                  class="custom-menu"
                  @select="mainStore.handleMenuSelect">
            <a-menu-item v-for="item in mainStore.menuList"
                         :key="item.key"
                         :id="`menu-item-${item.key}`"
                         class="custom-menu-item">
              <span class="menu-icon">
                <component :is="item.icon"/>
              </span>
              <span class="menu-label">{{ item.label }}</span>
              <span v-if="item.count !== undefined" class="menu-count">{{ item.count }}</span>
            </a-menu-item>
          </a-menu>
        </div>
        <!-- 外链（需要可自行添加，修改链接即可） -->
        <div class="sider-footer">
          <div class="sider-link">
            <span class="link-text" @click="mainStore.openExternalLink('https://github.com/babalae/better-genshin-impact')">
              {{ $t('sider.mainRepo') }}
            </span>
          </div>
          <div class="sider-link">
            <span class="link-text" @click="mainStore.openExternalLink('https://github.com/babalae/bettergi-scripts-list')">
              {{ $t('sider.scriptRepo') }}
            </span>
          </div>
          <div class="sider-link">
            <span v-if="mainStore.isModeSingle" class="link-text" @click="mainStore.openExternalLink('https://bgi.sh')">
              {{ $t('sider.onlineRepo') }}
            </span>
          </div>
          <div class="sider-link">
            <span class="link-text" @click="mainStore.openExternalLink('https://www.bettergi.com/open.html')">
              {{ $t('sider.otherExtensions') }}
            </span>
          </div>
          <div class="sider-link">
            <span class="link-text" @click="mainStore.openExternalLink('https://www.bettergi.com/doc.html')">
            {{ $t('sider.document') }}
            </span>
          </div>
        </div>
      </div>
      <!-- 最后更新时间 -->
      <div v-if="mainStore.lastUpdateTime"
           class="last-update-time"
           @click="mainStore.showEggModal = true">
        <div class="update-content" :class="{ 'column-mode': mainStore.isModeSingle }">
          <template v-if="mainStore.isModeSingle">
            <div class="update-label">{{ $t('sider.lastUpdate') }}</div>
            <div class="update-time">{{ mainStore.lastUpdateTime }}</div>
          </template>
          <template v-else>
            <span>{{ $t('sider.lastUpdate') + mainStore.lastUpdateTime }}</span>
          </template>
        </div>
      </div>
    </div>

    <!-- 中间内容区域 -->
    <div class="script-slider" :style="{ width: scriptSliderWidth + 'px' }">
      <div class="script-header">
        <span class="script-title">{{ mainStore.currentMenuTitle }}</span>
        <div v-if="mainStore.isModeSingle" class="script-actions">
          <a-button :type="mainStore.scriptTab === 'all' ? 'primary' : 'default'"
                    class="script-btn"
                    @click="mainStore.onClickShowAll">{{ $t('button.all') }}
          </a-button>
          <a-button :type="mainStore.scriptTab === 'subscribed' ? 'primary' : 'default'"
                    class="script-btn"
                    @click="mainStore.onClickShowSubscribed">{{ $t('button.subscribed') }}
          </a-button>
        </div>
      </div>
      <div class="search-section">
        <a-input v-model:value="mainStore.search"
                 :placeholder="mainStore.searchPlaceholder"
                 class="script-search"
                 @change="mainStore.handleSearch"
                 allow-clear>
          <template #prefix>
            <SearchOutlined/>
          </template>
        </a-input>
        <a-dropdown v-if="mainStore.selectedMenu[0] !== '1'"
                    placement="bottomLeft"
                    :trigger="'click'"
                    class="sort-dropdown"
                    v-model:open="mainStore.sortDropdownOpen">
          <a-button class="sort-button" size="middle">
            <AlignRightOutlined/>
          </a-button>
          <template #overlay>
            <a-menu
                class="sort-menu"
                :triggerSubMenuAction="'click'"
                :forceSubMenuRender="true"
                @click="mainStore.handleSortMenuClick"
            >
              <a-menu-item-group :title="$t('sort.sortBy')">
                <a-menu-item v-if="hasSearchKey" key="relevance" :class="{ active: mainStore.sortType === 'relevance' }">
                  <span>{{ $t('sort.relevance') }}</span>
                  <CheckOutlined v-if="mainStore.sortType === 'relevance'" class="check-icon"/>
                </a-menu-item>
                <a-menu-item key="time" :class="{ active: mainStore.sortType === 'time' }">
                  <span>{{ $t('sort.time') }}</span>
                  <CheckOutlined v-if="mainStore.sortType === 'time'" class="check-icon"/>
                </a-menu-item>
                <a-menu-item key="random" :class="{ active: mainStore.sortType === 'random' }">
                  <span>{{ $t('sort.random') }}</span>
                  <CheckOutlined v-if="mainStore.sortType === 'random'" class="check-icon"/>
                </a-menu-item>
                <a-menu-item key="name" :class="{ active: mainStore.sortType === 'name' }">
                  <span>{{ $t('sort.name') }}</span>
                  <CheckOutlined v-if="mainStore.sortType === 'name'" class="check-icon"/>
                </a-menu-item>
              </a-menu-item-group>
              <a-menu-divider/>
              <a-menu-item-group :title="$t('sort.sortOrder')">
                <a-menu-item key="asc" :class="{ active: mainStore.sortOrder === 'asc' }">
                  <span>{{ $t('sort.ascending') }}</span>
                  <CheckOutlined v-if="mainStore.sortOrder === 'asc'" class="check-icon"/>
                </a-menu-item>
                <a-menu-item key="desc" :class="{ active: mainStore.sortOrder === 'desc' }">
                  <span>{{ $t('sort.descending') }}</span>
                  <CheckOutlined v-if="mainStore.sortOrder === 'desc'" class="check-icon"/>
                </a-menu-item>
              </a-menu-item-group>
              <a-menu-divider v-if="mainStore.selectedMenu[0] === '3'"/>
              <a-menu-item-group :title="$t('sort.filter')" v-if="mainStore.selectedMenu[0] === '3'">
                <a-sub-menu>
                  <template #title>
                    <span>{{ $t('sort.filterByRole') }}</span>
                  </template>
                  <div class="role-filter-panel" @mousedown.stop @click.stop>
                    <a-input v-model:value="mainStore.roleFilterSearch"
                             size="middle"
                             class="role-filter-search"
                             :placeholder="$t('sort.searchRole')">
                      <template #prefix>
                        <SearchOutlined/>
                      </template>
                    </a-input>
                    <div class="role-filter-list">
                      <div
                          class="role-item"
                          v-for="tag in mainStore.displayedRoleTags"
                          :key="tag"
                          @click="mainStore.onRoleItemClick(tag)"
                      >
                        <img class="role-avatar" :src="mainStore.getRoleAvatar(tag)" alt="avatar"/>
                        <a-checkbox
                            :checked="mainStore.selectedRoleTags.includes(tag)"
                            :disabled="!mainStore.selectedRoleTags.includes(tag) && mainStore.selectedRoleTags.length >= 4"
                            class="role-filter-checkbox"
                            @click.stop
                            @change="mainStore.onRoleCheckboxChange(tag, $event)"
                        >
                          <span class="role-filter-label">{{ tag }}</span>
                        </a-checkbox>
                      </div>
                    </div>

                    <div class="role-filter-footer">
                      <div class="role-choose-text">{{ $t('sort.selected') }}</div>
                      <a-button v-for="avatar in mainStore.selectedRoleTags"
                                size="middle"
                                type="default"
                                class="role-filter-avatar"
                                @click="mainStore.onRoleItemClick(avatar)">
                        {{ avatar }}
                      </a-button>
                      <a-button size="middle"
                                type="primary"
                                class="role-filter-btn-primary"
                                @click="mainStore.resetRoleFilter">
                        {{ $t('common.reset') }}
                      </a-button>
                    </div>
                  </div>
                </a-sub-menu>
              </a-menu-item-group>
            </a-menu>
          </template>
        </a-dropdown>
      </div>
      <!-- 地图追踪的树状结构 -->
      <div v-if="mainStore.selectedMenu[0] === '1'" class="script-list">
        <MapTreeList ref="mapTreeListRef"/>
      </div>
      <!-- Javascript脚本列表 -->
      <div v-else-if="mainStore.selectedMenu[0] === '2'" class="script-list">
        <ScriptList ref="scriptListRef"/>
      </div>
      <!-- 战斗策略列表 -->
      <div v-else-if="mainStore.selectedMenu[0] === '3'" class="script-list">
        <CombatStrategyList ref="combatStrategyListRef"/>
      </div>
      <!-- 七圣召唤策略列表 -->
      <div v-else-if="mainStore.selectedMenu[0] === '4'" class="script-list">
        <CardStrategyList ref="cardStrategyListRef"/>
      </div>
    </div>

    <!-- 拖动分隔条 -->
    <div class="resize-handle" @mousedown="startResize"></div>

    <!-- 右侧内容区域 -->
    <a-layout class="main-right">
      <!-- 顶部操作栏 -->
      <div class="detail-top-bar">
        <div class="top-bar-left">
          <a-tooltip v-if="mainStore.isModeSingle" :title="$t('action.update')">
            <a-button type="text" class="action-btn" @click="settings.showUpdateMessageModal = true">
              <FieldTimeOutlined />
            </a-button>
          </a-tooltip>
          <a-tooltip v-if="mainStore.isModeSingle" :title="$t('action.subscribe')">
            <a-button type="text" class="action-btn" @click="mainStore.showUpdateSubscribeModal = true">
              <CloudDownloadOutlined />
            </a-button>
          </a-tooltip>
        </div>
        <div class="top-bar-right">
<!--          <a-tooltip v-if="mainStore.isNewYear()" :title="'新春快乐'">-->
<!--            <a-button type="text" class="action-btn" @click="mainStore.openFireworksModal">-->
<!--              🧨-->
<!--            </a-button>-->
<!--          </a-tooltip>-->
          <a-tooltip :title="$t('action.announcement')">
            <a-button type="text" class="action-btn" @click="mainStore.showAnnouncementModal = true">
              <CalendarOutlined />
            </a-button>
          </a-tooltip>
<!--          <a-tooltip :title="$t('action.plan')">-->
<!--            <a-button type="text" class="action-btn" @click="mainStore.showPlanModal = true">-->
<!--              <EditOutlined />-->
<!--            </a-button>-->
<!--          </a-tooltip>-->
          <a-tooltip :title="$t('action.help')">
            <a-button type="text" class="action-btn" @click="mainStore.showHelpModal = true">
              <QuestionCircleOutlined/>
            </a-button>
          </a-tooltip>
          <a-tooltip :title="$t('settings.title')">
            <a-button type="text" class="action-btn" @click="settings.showSettingsModal = true">
              <SettingOutlined/>
            </a-button>
          </a-tooltip>
        </div>
      </div>
      <div v-if="mainStore.selectedMenu[0] === '1'" class="main-right-container">
        <MapDetail/>
      </div>
      <div v-else-if="mainStore.selectedMenu[0] === '2'" class="main-right-container">
        <ScriptDetail/>
      </div>
      <div v-else-if="mainStore.selectedMenu[0] === '3' || mainStore.selectedMenu[0] === '4'" class="main-right-container">
        <StrategyDetail/>
      </div>
    </a-layout>

    <!-- 错误弹窗 -->
    <div v-if="mainStore.repoError"
         class="repo-error-modal">
      <div class="repo-error-content">
        <div class="repo-error-icon">
          <svg width="48" height="48" viewBox="0 0 48 48" fill="none">
            <circle cx="24" cy="24" r="24" fill="#fdecea"/>
            <path d="M24 14v12" stroke="#f44336" stroke-width="3" stroke-linecap="round"/>
            <circle cx="24" cy="32" r="2.5" fill="#f44336"/>
          </svg>
        </div>
        <div class="repo-error-title">{{ $t('repoError.title') }}</div>
        <div class="repo-error-desc">{{ $t('repoError.desc') }}</div>
        <div class="repo-error-btn-group">
          <a-button class="repo-error-btn"
                    @click="fetchRepoData"
                    type="primary"
                    danger>{{ $t('repoError.refresh') }}
          </a-button>
          <a-button class="repo-help-btn"
                    @click="mainStore.showHelpModal = true"
                    type="primary">{{ $t('repoError.help') }}
          </a-button>
        </div>
      </div>
    </div>

    <!-- 全局加载弹窗 -->
    <div v-if="mainStore.globalLoading"
         class="global-loading-modal">
      <a-spin size="large" :tip="`${$t('loading.repoData')}...`"/>
    </div>

    <!-- 彩蛋弹窗 -->
    <a-modal v-model:open="mainStore.showEggModal"
             :title="$t('egg.title')"
             :footer="null"
             centered
             width="80%"
             :style="{ maxWidth: '900px' }"
             :destroyOnClose="true"
             @cancel="mainStore.showEggModal = false">
      <div class="egg-modal-content">
        <div class="egg-readme-tabs">
          <div v-if="mainStore.isLoadingEggReadme" class="egg-readme-loading-indicator">
            <a-spin size="small"/>
            <span>{{ $t('egg.loading') }}</span>
          </div>
          <div v-else-if="mainStore.eggReadmeError" class="egg-readme-loading-indicator">
            <a-button type="text" size="small" @click="mainStore.retryLoadEggReadme">
              <template #icon>
                <ReloadOutlined/>
              </template>
            </a-button>
            <span>{{ $t('egg.failed') }}</span>
          </div>
        </div>
        <div class="egg-readme-content">
          <ReadmeViewer :path="'https://raw.githubusercontent.com/zaodonganqi/BGI-bsw-egg/main/README.md'"
                        :force-web="true"
                        @loaded="mainStore.handleEggReadmeLoaded"
                        @error="mainStore.handleEggReadmeError"/>
        </div>
      </div>
    </a-modal>

    <!-- 更新信息弹窗 -->
    <a-modal v-model:open="settings.showUpdateMessageModal"
             :title="$t('action.recent')"
             :footer="null"
             centered width="50%"
             :style="{ maxWidth: '900px' }">
      <div class="update-message-content">
        <a-list :data-source="mainStore.updatedScripts" size="small">
          <template #renderItem="{ item, index }">
            <div class="update-list-item">
              <div class="item-header">
                <span class="item-index">{{ index + 1 }}.</span>
                <span class="item-title">{{ item.name }}</span>
              </div>
              <div class="item-path">{{ item.path }}</div>
              <div class="item-time" v-if="item.lastUpdated">{{ $t('detail.lastUpdated') }}:{{ item.lastUpdated }}</div>
            </div>
          </template>
        </a-list>
      </div>
      <div class="update-modal-footer">
        <a-button type="primary"
                  size="middle"
                  @click="settings.handleClearUpdate(mainStore)"
                  :loading="settings.clearUpdateLoading">
          {{ $t('action.clearDot') }}
        </a-button>
      </div>
    </a-modal>

    <!-- 一键更新弹窗 -->
    <a-modal
      v-model:open="mainStore.showUpdateSubscribeModal"
      :title="$t('action.updateAll')"
      :ok-text="$t('action.confirm')"
      :cancel-text="$t('action.cancel')"
      centered
      width="50%"
      :style="{ maxWidth: '900px' }"
      @ok="mainStore.updateSubscribedScripts"
      :confirmLoading="mainStore.updatingSubscribed"
      :maskClosable="!mainStore.updatingSubscribed"
      :keyboard="!mainStore.updatingSubscribed"
      :closable="!mainStore.updatingSubscribed"
      :cancelButtonProps="{ disabled: mainStore.updatingSubscribed }"
    >
      <div class="update-subscribe-content">
        <a-list :data-source="mainStore.subscribedScripts" size="small">
          <template #renderItem="{ item, index }">
            <div class="update-list-item">
              <div class="item-header">
                <span class="item-index">{{ index + 1 }}.</span>
                <span class="item-title">{{ item[0] }}</span>
              </div>
              <div class="item-path">{{ item[1] }}</div>
            </div>
          </template>
        </a-list>
      </div>
    </a-modal>

    <!-- 公告弹窗 -->
    <a-modal v-model:open="mainStore.showAnnouncementModal"
             :title="$t('action.announcement')"
             centered
             width="70%"
             :footer="null"
             @ok="mainStore.showAnnouncementModal = false">
      <Announcement/>
    </a-modal>

<!--    &lt;!&ndash; 烟花弹窗 &ndash;&gt;-->
<!--    <Fireworks />-->

    <!-- 更新计划弹窗 -->
<!--    <a-modal v-model:open="mainStore.showPlanModal"-->
<!--             :title="$t('plan.title')"-->
<!--             :footer="null"-->
<!--             centered width="80%"-->
<!--             :style="{ maxWidth: '900px' }"-->
<!--             @cancel="mainStore.showPlanModal = false">-->
<!--      <Plan/>-->
<!--    </a-modal>-->

    <!-- 更新提醒弹窗 -->
<!--    <a-modal v-model:open="mainStore.showUpdateNoticeModal"-->
<!--             :title="$t('update.notice.title')"-->
<!--             centered-->
<!--             width="auto"-->
<!--             :closable="false"-->
<!--             :maskClosable="false"-->
<!--             :cancelButtonProps="{ style: { display: 'none' } }"-->
<!--             :ok-text="mainStore.okButtonText"-->
<!--             :confirm-loading="mainStore.updateNoticeModalLoading"-->
<!--             @ok="mainStore.closeUpdateNoticeModal">-->
<!--      <UpdateNotice/>-->
<!--    </a-modal>-->

    <!-- 帮助弹窗 -->
    <a-modal v-model:open="mainStore.showHelpModal"
             :title="$t('help.title')"
             :footer="null"
             centered
             width="80%"
             :style="{ maxWidth: '900px' }"
             @cancel="mainStore.showHelpModal = false">
      <Help/>
    </a-modal>

    <!-- 设置弹窗 -->
    <a-modal v-model:open="settings.showSettingsModal"
             :title="$t('settings.title')"
             :footer="null"
             centered
             width="500px"
             @cancel="settings.showSettingsModal = false">
      <div class="settings-row">
        <span class="settings-label">{{ $t('settings.language') }}</span>
        <a-select :value="settings.selectedLocale"
                  size="middle"
                  style="width: 120px;"
                  :dropdownMatchSelectWidth="false"
                  @change="onLocaleChange"
                  popupClassName="lang-select-dropdown">
          <a-select-option value="zh-CN">{{ $t('settings.zhCN') }}</a-select-option>
          <a-select-option value="zh-TW">{{ $t('settings.zhTW') }}</a-select-option>
          <a-select-option value="en-US">{{ $t('settings.enUS') }}</a-select-option>
          <a-select-option value="ja-JP">{{ $t('settings.jaJP') }}</a-select-option>
          <a-select-option value="fr-FR">{{ $t('settings.frFR') }}</a-select-option>
        </a-select>
      </div>
      <a-divider/>
      <div class="settings-row">
        <span class="settings-label">{{ $t('settings.theme') }}</span>
        <div class="theme-controls-wrapper">
          <div class="theme-controls">
            <a-button v-if="settings.selectedThemeName === 'transparent'" 
                     type="primary" 
                     size="middle" 
                     @click="triggerFileUpload"
                     class="upload-btn">
              {{ $t('settings.uploadBackground') }}
            </a-button>
            <a-select :value="settings.selectedThemeName"
                      size="middle"
                      style="width: 120px;"
                      :dropdownMatchSelectWidth="false"
                      @change="settings.onThemeChange"
                      popupClassName="lang-select-dropdown">
              <a-select-option v-for="theme in settings.themeList" :key="theme.key" :value="theme.key">
                {{ theme.name[settings.selectedLocale] }}
              </a-select-option>
            </a-select>
          </div>
        </div>
      </div>
      <a-divider/>
      <div class="settings-row">
        <span class="settings-label">{{ $t('settings.guide') }}</span>
        <a-button type="primary"
                  size="middle"
                  @click="mainStore.startGuide">
          <template #icon>
            <CompassOutlined/>
          </template>
          {{ $t('settings.startGuide') }}
        </a-button>
      </div>
      <a-divider v-if="mainStore.isModeSingle"/>
      <div v-if="mainStore.isModeSingle" class="settings-row">
        <span class="settings-label">{{ $t('settings.clearUpdate') }}</span>
        <a-button type="primary"
                  size="middle"
                  @click="settings.handleClearUpdate(mainStore)"
                  :loading="settings.clearUpdateLoading">
          {{ $t('settings.clearUpdateBtn') }}
        </a-button>
      </div>
    </a-modal>
    
    <!-- 安全声明弹窗 -->
    <a-modal
      v-model:open="settings.showSafetyModal"
      :title="$t('settings.eggSafetyTitle')"
      :ok-text="$t('settings.eggSafetyOk')"
      :cancel-text="$t('settings.eggSafetyCancel') || $t('action.cancel')"
      centered
      width="520px"
      @ok="settings.useTheme()"
      @cancel="() => settings.cancelSafety()"
    >
      <div class="safety-modal-content">
        <div class="safety-warning-icon" aria-hidden="true">⚠</div>
        <div class="safety-text">{{ $t('settings.eggSafetyDesc') }}</div>
      </div>
    </a-modal>

    <!-- 开发者通道：跳过新手引导 -->
    <div v-if="mainStore.showGuide" class="dev-skip-btn" @click="mainStore.skipGuideDev"></div>

    <!-- 隐藏的文件输入 -->
    <input ref="fileInput" type="file" accept="image/*" style="display: none;" @change="handleFileChange" />
  </a-layout>
</template>

<script setup>
import {computed, onMounted, onUnmounted, ref} from 'vue';
import {useRoute, useRouter} from 'vue-router';
import {useSettingsStore} from '@/stores/settingsStore.js';
import { useUrlSync } from '@/utils/routerHelper.js'
import {
  AlignRightOutlined,
  CheckOutlined,
  CloudDownloadOutlined,
  EditOutlined,
  FieldTimeOutlined,
  QuestionCircleOutlined,
  ReloadOutlined,
  SearchOutlined,
  SettingOutlined,
  CalendarOutlined,
  CompassOutlined
} from '@ant-design/icons-vue';
import MapTreeList from './lists/MapTreeList.vue';
import ScriptList from './lists/ScriptList.vue';
import CombatStrategyList from './lists/CombatStrategyList.vue';
import CardStrategyList from './lists/CardStrategyList.vue';
import ScriptDetail from './details/ScriptDetail.vue';
import StrategyDetail from './details/StrategyDetail.vue';
import MapDetail from './details/MapDetail.vue';
import ReadmeViewer from './items/ReadmeViewer.vue';
import Help from './items/Help.vue';
import { useI18n } from 'vue-i18n';
// import Plan from "./items/Plan.vue";
import { useMainStore } from "@/stores/mainStore.js";
// import UpdateNotice from "@/components/items/UpdateNotice.vue";
import Announcement from "@/components/items/Announcement.vue";
// import Fireworks from "@/components/items/Fireworks.vue";

const mainStore = useMainStore();
const settings = useSettingsStore();
const route = useRoute();
const router = useRouter();

// 目录内四个子组件引用
const mapTreeListRef = ref(null);
const scriptListRef = ref(null);
const combatStrategyListRef = ref(null);
const cardStrategyListRef = ref(null);

// 文件上传相关
const fileInput = ref(null);

// 触发文件上传
function triggerFileUpload() {
  fileInput.value?.click();
}

// 处理文件选择
function handleFileChange(event) {
  const file = event.target.files?.[0];
  if (file) {
    settings.handleFileUpload(file);
  }
  // 清空input值，允许重复选择同一文件
  event.target.value = '';
}

// 布局宽度管理
const scriptSliderWidth = ref(0);
const isResizing = ref(false);

// 宽度限制常量
const SCRIPT_MIN_WIDTH = 250;
const SCRIPT_MAX_WIDTH = 700;

// 动态计算两列布局阈值
const getTwoColumnThreshold = () => {
  const windowWidth = window.innerWidth;
  return Math.max(windowWidth * 0.20, 400);
};

// 缓存键名
const SCRIPT_WIDTH_CACHE_KEY = 'script-slider-width';

// 保存宽度到缓存
const saveWidthToCache = (width) => {
  localStorage.setItem(SCRIPT_WIDTH_CACHE_KEY, width.toString());
};

// 从缓存读取宽度
const getWidthFromCache = () => {
  const cachedWidth = localStorage.getItem(SCRIPT_WIDTH_CACHE_KEY);
  if (cachedWidth) {
    const width = parseInt(cachedWidth, 10);
    // 验证宽度是否在有效范围内
    if (width >= SCRIPT_MIN_WIDTH && width <= SCRIPT_MAX_WIDTH) {
      return width;
    }
  }
  return null;
};

// 初始化布局宽度
const initLayoutWidths = () => {
  // 优先使用缓存的宽度
  const cachedWidth = getWidthFromCache();
  let newWidth;
  
  if (cachedWidth) {
    // 使用缓存的宽度
    newWidth = cachedWidth;
  } else {
    // 使用默认宽度
    const windowWidth = window.innerWidth;
    const defaultScriptWidth = Math.min(windowWidth * 0.23, 500);
    newWidth = Math.min(Math.max(defaultScriptWidth, SCRIPT_MIN_WIDTH), SCRIPT_MAX_WIDTH);
  }
  
  scriptSliderWidth.value = newWidth;
  
  // 初始化时设置两列布局状态判断
  // mainStore.isListTwoColumn = newWidth >= getTwoColumnThreshold();
};

// 拖动处理（第二栏和第三栏之间）
const handleResize = (e) => {
  if (!isResizing.value) return;

  const windowWidth = window.innerWidth;
  const leftSliderWidth = Math.min(windowWidth * 0.18, 300);
  const mouseX = e.clientX;
  
  // 计算第二栏的右边界位置
  const scriptRightBoundary = leftSliderWidth + 3;

  // 设置最终宽度
  const newWidth = Math.min(Math.max(mouseX - scriptRightBoundary, SCRIPT_MIN_WIDTH), SCRIPT_MAX_WIDTH);
  scriptSliderWidth.value = newWidth;
  
  // 更新 mainStore 中的两列布局状态
  // mainStore.isListTwoColumn = newWidth >= getTwoColumnThreshold();
  
  // 保存宽度到缓存
  saveWidthToCache(newWidth);
};


// 拖动开始（第二栏和第三栏之间）
const startResize = (e) => {
  isResizing.value = true;
  document.addEventListener('mousemove', handleResize);
  document.addEventListener('mouseup', stopResize);
  document.body.style.cursor = 'col-resize';
  document.body.style.userSelect = 'none';
  e.preventDefault();
};

// 拖动结束（第二栏和第三栏之间）
const stopResize = () => {
  isResizing.value = false;
  document.removeEventListener('mousemove', handleResize);
  document.removeEventListener('mouseup', stopResize);
  document.body.style.cursor = '';
  document.body.style.userSelect = '';
};


// 窗口大小变化处理
const handleWindowResize = () => {
  if (!isResizing.value) {
    initLayoutWidths();
  }
};

// 判断是否有搜索关键词
const hasSearchKey = computed(() => {
  return mainStore.search && mainStore.search.trim() !== '';
});

// 采用vue-i18n组件获取选中语言的文本
const { t: $t } = useI18n();

// 挂载时获取仓库数据并应用部分排序
// 获取仓库数据
const fetchRepoData = async () => {
  await mainStore.getRepoJson();
  if (!mainStore.repoError) {
    if (['2', '3', '4'].includes(mainStore.selectedMenu[0])) {
      mainStore.applySortForMenu(mainStore.selectedMenu[0]);
    }
    mainStore.selectedRoleTags = [...mainStore.appliedRoleTags];

    // 检测版本
    mainStore.checkAppVersionIsNew();
  }
};

// URL 双向同步
const { restoreFromUrl } = useUrlSync({
  mainStore,
  route,
  router,
  getRefs: () => ({ pathing: mapTreeListRef, js: scriptListRef, combat: combatStrategyListRef, tcg: cardStrategyListRef }),
});

// 挂载时获取仓库数据并应用部分排序
onMounted(async () => {
  await fetchRepoData();

  // 初始化布局宽度
  initLayoutWidths();

  // 监听窗口大小变化
  window.addEventListener('resize', handleWindowResize);

  // 加载自定义背景
  await settings.loadCustomBackground();

  // 新手引导检测
  mainStore.checkGuide();

  // 等待引导结束后恢复 URL 状态
  await mainStore.guideReady;
  await restoreFromUrl();

  // mainStore.checkFireworksModal();
});

// 组件卸载时清理事件监听器
onUnmounted(() => {
  window.removeEventListener('resize', handleWindowResize);
  if (isResizing.value) {
    document.removeEventListener('mousemove', handleResize);
    document.removeEventListener('mouseup', stopResize);
  }
});

// 选择语言切换
function onLocaleChange(val) {
  // mainStore.onLocaleChange(val);
  settings.setLocale(val);
}
</script>

<style scoped>
.main-layout {
  height: 100vh;
  width: 100%;
  margin: 0;
  display: flex;
  flex-flow: row;
}

.custom-sider {
  width: 18% !important;
  max-width: 300px !important;
  min-width: 250px !important;
  border-right: 1px solid var(--border-base);
  display: flex;
  flex-direction: column;
  padding: 0;
  height: 100%;
  flex-shrink: 0;
}

.sider-header {
  height: 60px;
  display: flex;
  align-items: center;
  padding: 0 16px;
  font-weight: 600;
  font-size: 18px;
  background-color: var(--bg-menu);
  backdrop-filter: blur(5px);
  border-bottom: 1px solid var(--border-base);
  width: 100%;
  flex-shrink: 0;
  position: relative;
}

.sider-logo {
  width: 40px;
  height: 40px;
  background: url('@/assets/favicon.ico') no-repeat center/contain;
  margin-right: 10px;
  flex-shrink: 0;
  cursor: pointer;
  transition: opacity 0.2s;
}

.sider-logo:hover {
  opacity: 0.8;
}

.repo-title {
  font-size: 16px;
  font-weight: 600;
  margin-left: 10px;
  align-items: center;
}

.sider-menu-wrap {
  padding: 8px;
  width: 100%;
  background-color: var(--bg-menu);
  overflow-y: auto;
  overflow-x: hidden;
  display: flex;
  flex-direction: column;
  height: calc(100% - 60px - 60px);
}

.menu-content {
  overflow-y: auto;
  overflow-x: hidden;
  border-radius: 6px;
  backdrop-filter: blur(5px);
}

.custom-menu {
  width: 100%;
  background-color: var(--bg-menu);
}

.custom-menu-item {
  display: flex;
  align-items: center;
  font-size: 15px;
  border-radius: 8px;
  margin: 0 8px;
  padding: 12px 16px !important;
  min-width: 0;
  height: auto;
  transition: all 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
  position: relative;
  overflow: hidden;
  transform-origin: left center;
}

/* 优化 Ant Design Vue Menu 组件的动画效果 */
:deep(.ant-menu) {
  border: none !important;
  transition: all 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
}

:deep(.ant-menu-item) {
  width: 90%;
  transition: all 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94) !important;
}

:deep(.ant-menu-item:hover) {
  transition: all 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94) !important;
}

:deep(.ant-menu-item-selected) {
  transition: all 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94) !important;
}

/* 优化 Menu 展开/折叠动画 */
:deep(.ant-menu-submenu-expand-icon) {
  transition: all 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
}

:deep(.ant-menu-submenu-title) {
  transition: all 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
}

:deep(.ant-menu-submenu-title:hover) {
  transition: all 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
}

/* 优化 Menu 子菜单动画 */
:deep(.ant-menu-sub) {
  animation: menuSlideIn 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
}

@keyframes menuSlideIn {
  from {
    opacity: 0;
    transform: translateX(-10px) scaleX(0.95);
  }
  to {
    opacity: 1;
    transform: translateX(0) scaleX(1);
  }
}

:deep(.ant-menu-item-selected) {
  background: var(--bg-item-selected);
  color: var(--color-primary);
  transform: translateX(8px);
  box-shadow: 2px 6px 16px rgba(22, 119, 255, 0.2) !important;
  transition: all 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
}

:deep(.ant-menu-item-selected):hover {
  background: var(--bg-item-selected);
  box-shadow: 8px 8px 20px rgba(22, 119, 255, 0.25);
}

.menu-icon {
  margin-right: 10px;
  font-size: 18px;
  flex-shrink: 0;
  transition: all 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
}

.custom-menu-item:hover .menu-icon {
  transform: scale(1.15) rotate(5deg);
  color: var(--color-primary);
}

.menu-label {
  flex: 1 1 0;
  min-width: 0;
  transition: all 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
}

.custom-menu-item:hover .menu-label {
  color: var(--color-primary);
  transform: translateY(-1px);
}

.menu-count {
  font-size: 13px;
  margin-left: 8px;
  flex-shrink: 0;
  color: var(--text-base3);
  transition: all 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
  background-color: var(--bg-container);
  padding: 2px 8px;
  border-radius: 12px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.custom-menu-item:hover .menu-count {
  background-color: var(--color-primary);
  color: white;
  transform: scale(1.1) translateY(-2px);
  box-shadow: 0 4px 8px rgba(22, 119, 255, 0.3);
}

/* 菜单项选中动画 */
:deep(.ant-menu-item-selected)::before {
  content: '';
  position: absolute;
  left: 0;
  top: 0;
  bottom: 0;
  width: 4px;
  background-color: var(--color-primary);
  border-radius: 0 4px 4px 0;
}

:deep(.ant-menu-item-selected) .menu-count {
  background-color: var(--color-primary);
  color: white;
  transform: scale(1.1) translateY(-2px);
  box-shadow: 0 4px 8px rgba(22, 119, 255, 0.3);
}

/* 菜单项点击效果 */
.custom-menu-item::after {
  content: '';
  position: absolute;
  top: 50%;
  left: 50%;
  width: 0;
  height: 0;
  border-radius: 50%;
  background-color: rgba(22, 119, 255, 0.3);
  transform: translate(-50%, -50%);
  transition: width 0.6s, height 0.6s;
}

.custom-menu-item:active::after {
  width: 300px;
  height: 300px;
}

.sider-footer {
  padding: 24px 16px;
  font-size: 14px;
  border-top: 1px solid var(--border-base);
  color: var(--text-base3);
  backdrop-filter: blur(5px);
  width: 100%;
  flex-shrink: 0;
}

.sider-link {
  margin-bottom: 14px;
  cursor: pointer;
}

.link-text {
  position: relative;
  display: inline-block;
}

/* 下划线 */
.link-text::after {
  content: '';
  position: absolute;
  left: 0;
  bottom: -4px;
  width: 100%;
  height: 1px;
  background-color: var(--text-base3);
  transform: scaleX(0);
  transform-origin: left;
  transition: transform 0.25s ease;
}

.sider-link:hover .link-text::after {
  transform: scaleX(1);
}

.last-update-time {
  padding: 12px 25px;
  font-size: 12px;
  border-top: 1px solid var(--border-base);
  color: var(--text-base2);
  background: var(--bg-menu);
  backdrop-filter: blur(5px);
  width: 100%;
  flex-shrink: 0;
  height: 60px;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  cursor: pointer;
}

.last-update-time.column-mode {
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  height: auto;
  gap: 0;
  padding-bottom: 8px;
}

.last-update-time span {
  font-size: 15px;
}

.script-slider {
  border-right: 1px solid var(--border-base);
  background: var(--bg-menu);
  height: 100%;
  position: relative;
  flex-shrink: 0;
}

.script-header {
  height: 60px;
  padding: 16px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  backdrop-filter: blur(5px);
  border-bottom: 1px solid var(--border-base);
}

.script-title {
  font-size: 16px;
  font-weight: 600;
}

.script-actions {
  position: relative;
  display: flex;
  gap: 8px;
}

.script-btn {
  height: 30px;
  padding: 0 12px;
  font-size: 14px;
}

.search-section {
  display: flex;
  flex-direction: row;
  align-items: center;
  height: 60px;
  padding: 10px 16px;
  border-bottom: 1px solid var(--border-base);
  backdrop-filter: blur(5px);
  gap: 8px;
}

:deep(.ant-input-affix-wrapper >input.ant-input) {
  background: transparent;
}

.script-search {
  flex: 1;
  height: 44px;
  transition: all 0.3s var(--ease-in-out);
}

.script-search:hover {
  transform: translateY(-1px);
}

:deep(.ant-input-affix-wrapper) {
  transition: all 0.3s var(--ease-in-out);
  border-radius: 8px;
}

:deep(.ant-input-affix-wrapper):hover {
  border-color: var(--color-primary);
  box-shadow: 0 4px 12px rgba(22, 119, 255, 0.15);
}

:deep(.ant-input-affix-wrapper:focus-within) {
  border-color: var(--color-primary);
  box-shadow: 0 0 0 2px rgba(22, 119, 255, 0.2);
}

.sort-dropdown {
  flex-shrink: 0;
}

.sort-button {
  height: 44px;
  width: 44px;
  border: 1px solid var(--border-base);
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 18px;
  padding: 0;
  box-shadow: none;
  transition: all 0.3s var(--ease-in-out);
  position: relative;
  overflow: hidden;
}

.sort-button:hover {
  transform: translateY(-1px);
  border-color: var(--color-primary);
  color: var(--color-primary);
  box-shadow: 0 4px 12px rgba(22, 119, 255, 0.15);
}

.sort-button:focus {
  outline: none;
  border-color: var(--color-primary);
  color: var(--color-primary);
  box-shadow: 0 0 0 2px rgba(22, 119, 255, 0.2);
}

.sort-button:active {
  transform: scale(0.95);
}

/* 排序按钮点击效果 */
.sort-button::after {
  content: '';
  position: absolute;
  top: 50%;
  left: 50%;
  width: 0;
  height: 0;
  border-radius: 50%;
  background-color: rgba(22, 119, 255, 0.3);
  transform: translate(-50%, -50%);
  transition: width 0.6s, height 0.6s;
}

.sort-button:active::after {
  width: 300px;
  height: 300px;
}

.sort-menu {
  min-width: 120px;
}

.role-filter-panel {
  max-height: 50vh;
  padding: 8px 12px 12px 12px;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  box-sizing: border-box;
}

.role-filter-search :deep(.ant-input-affix-wrapper) {
  height: 34px;
  border-radius: 8px;
}

.role-filter-list {
  flex: 1;
  overflow-y: auto;
  padding-right: 4px;
  display: grid;
  margin: 8px 0;
  grid-template-columns: repeat(4, 1fr);
  gap: 8px 5px;
}

.role-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  cursor: pointer;
  gap: 8px;
}

.role-avatar {
  width: 80px;
  height: 80px;
  border-radius: 8px;
}

.role-filter-checkbox :deep(.ant-checkbox) {
  transform: translateY(-1px);
}

.role-filter-label {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.role-filter-footer {
  display: flex;
  justify-content: flex-start;
  gap: 8px;
  padding: 8px 10px 0 10px;
  border-top: 1px solid var(--border-base);
}

.role-choose-text {
  display: flex;
  text-align: center;
  align-items: center;
  color: var(--text-base);
}

.role-filter-avatar {
  border-radius: 8px;
  padding: 0 12px;
  border-color: var(--color-primary);
  color: var(--color-primary);
}

.role-filter-avatar::after {
  content: 'X';
  position: absolute;
  top: -4px;
  right: -4px;
  width: 16px;
  height: 16px;
  background-color: var(--text-error);
  color: #FFFFFF;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 10px;
  line-height: 1;
  font-family: Arial, sans-serif;
  opacity: 0;
  transform: scale(0.8);
  transition: all 0.2s ease;
  pointer-events: none;
}

.role-filter-avatar:hover::after {
  opacity: 1;
  transform: scale(1);
}

.role-filter-btn-primary {
  border-radius: 8px;
  padding: 0 14px;
  margin-left: auto;
}

.sort-menu .ant-menu-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 8px 16px;
}

.sort-menu .check-icon {
  color: var(--color-primary);
  font-size: 14px;
  margin-left: 8px;
}

.sort-menu .ant-menu-item-group-title {
  font-size: 13px;
  font-weight: 600;
  padding: 8px 16px 4px 16px;
}

.script-list {
  position: absolute;
  top: 120px;
  left: 0;
  right: 0;
  bottom: 0;
  width: 100%;
  overflow-x: hidden;
  overflow-y: auto;
}

.main-right {
  flex: 1;
  height: 100%;
  min-width: 0;
  overflow: hidden;
}

:deep(.main-right.ant-layout) {
  background: var(--bg-container);
  display: flex;
  flex-direction: column;
}

.main-right-container {
  flex: 1;
  height: 100%;
  overflow-x: auto;
  display: flex;
  flex-direction: column;
  min-width: 0;
}

.detail-top-bar {
  height: 60px;
  border-bottom: 1px solid var(--border-base);
  background-color: var(--bg-menu);
  backdrop-filter: blur(5px);
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 16px;
}

.top-bar-left {
  display: flex;
  margin-left: 1px;
  gap: 8px;
}

.top-bar-right {
  margin-left: auto;
  display: flex;
  gap: 8px;
}

.action-btn {
  border: none;
  padding: 8px;
  border-radius: 8px;
  color: var(--text-base2);
  transition: all 0.3s var(--ease-in-out);
  font-size: 22px;
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  overflow: hidden;
}

.action-btn:hover {
  transform: scale(1.1);
  color: var(--color-primary);
  background-color: var(--bg-shadow-light);
  box-shadow: 0 4px 12px rgba(22, 119, 255, 0.2);
}

.action-btn:active {
  transform: scale(0.95);
}

.action-btn::after {
  content: '';
  position: absolute;
  top: 50%;
  left: 50%;
  width: 0;
  height: 0;
  border-radius: 50%;
  background-color: rgba(22, 119, 255, 0.3);
  transform: translate(-50%, -50%);
  transition: width 0.6s, height 0.6s;
}

.action-btn:active::after {
  width: 300px;
  height: 300px;
}

.main-right>div:last-child {
  flex: 1;
  overflow: hidden;
}

.strategy-tabs :deep(.ant-tabs-content) {
  flex: 1;
  overflow-y: auto;
}

.repo-error-modal {
  position: fixed;
  left: 0;
  top: 0;
  right: 0;
  bottom: 0;
  z-index: 999;
  background: rgba(0, 0, 0, 0.18);
  display: flex;
  align-items: center;
  justify-content: center;
  animation: fadeIn 0.3s;
}

@keyframes fadeIn {
  from {
    opacity: 0;
  }

  to {
    opacity: 1;
  }
}

.repo-error-content {
  font-size: 18px;
  padding: 36px 48px 32px 48px;
  border-radius: 16px;
  box-shadow: 0 8px 32px var(--border-base);
  background: var(--bg-container);
  text-align: center;
  min-width: 320px;
  max-width: 90vw;
  animation: popIn 0.3s;
}

@keyframes popIn {
  from {
    transform: scale(0.9);
    opacity: 0;
  }

  to {
    transform: scale(1);
    opacity: 1;
  }
}

.repo-error-icon {
  margin-bottom: 16px;
}

.repo-error-title {
  font-size: 22px;
  font-weight: bold;
  margin-bottom: 8px;
  color: var(--text-error);
}

.repo-error-desc {
  font-size: 15px;
  margin-bottom: 24px;
  color: var(--text-base2);
}

.repo-error-btn-group {
  display: flex;
  flex-direction: row;
  gap: 16px;
  justify-content: center;
  margin-top: 8px;
}

.repo-error-btn {
  height: 40px;
  width: 120px;
  border: none;
  border-radius: 6px;
  font-size: 16px;
  cursor: pointer;
  transition: background 0.2s, box-shadow 0.2s;
}

:deep(.ant-btn-primary.ant-btn-dangerous) {
  box-shadow: none;
}

.repo-help-btn {
  height: 40px;
  width: 120px;
  border: none;
  border-radius: 6px;
  font-size: 16px;
  cursor: pointer;
  justify-content: center;
  transition: background 0.2s, box-shadow 0.2s;
}

.global-loading-modal {
  position: fixed;
  left: 0;
  top: 0;
  right: 0;
  bottom: 0;
  z-index: 99999;
  background: rgba(0, 0, 0, 0.30);
  display: flex;
  align-items: center;
  justify-content: center;
  backdrop-filter: blur(4px);
}

:deep(.ant-spin) {
  animation: pulse 2s infinite;
}

:deep(.ant-spin-dot-item) {
  background-color: var(--color-primary);
  width: 12px;
  height: 12px;
  animation-timing-function: cubic-bezier(0.785, 0.135, 0.15, 0.86);
}

:deep(.ant-spin-text) {
  margin-top: 16px;
  font-size: 16px;
  color: var(--text-base);
  animation: fadeIn 1s ease-out;
}

.egg-modal-content {
  max-height: 65vh;
  overflow-y: auto;
  padding-left: 15px;
  padding-right: 15px;
  font-size: clamp(14px, 1.5vw, 16px);
  position: relative;
}

.egg-readme-tabs {
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 16px;
  gap: 10px;
}

.egg-readme-loading-indicator {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 14px;
}

.egg-readme-content {
  flex: 1;
  overflow-y: auto;
  overflow-x: hidden;
}

.update-message-content {
  display: flex;
  flex-direction: column;
  max-height: 60vh;
  overflow-y: auto;
}

.update-list-item {
  padding: 12px 16px;
  border-bottom: 1px solid var(--border-base);
}

.update-list-item:last-child {
  border-bottom: none;
}

.item-header {
  font-size: 16px;
  font-weight: 600;
  display: flex;
  align-items: center;
}

.item-index {
  font-size: 15px;
  font-weight: bold;
  margin-right: 6px;
}

.item-title {
  word-break: break-all;
}

.item-path {
  font-size: 13px;
  margin-top: 4px;
  color: var(--text-base2);
  word-break: break-all;
}

.item-time {
  font-size: 13px;
  margin-top: 4px;
  color: var(--text-base2);
  word-break: break-all;
}

.update-modal-footer {
  display: flex;
  justify-content: flex-end;
  padding-top: 12px;
}

.update-subscribe-content {
  max-height: 60vh;
  overflow-y: auto;
}

.settings-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 8px;
}

.settings-label {
  font-size: 15px;
  font-weight: 500;
}

.theme-controls-wrapper {
  max-width: 350px;
  flex-shrink: 0;
  margin-left: auto;
}

.theme-controls {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 8px;
  justify-content: flex-end;
}

.upload-btn {
  white-space: nowrap;
  flex-shrink: 0;
}

:deep(.ant-select) {
  width: auto !important;
  min-width: 120px;
}

.update-label {
  font-size: 15px;
  line-height: 1.2;
}

.update-time {
  font-size: 14px;
  margin-top: 2px;
  line-height: 1.2;
}

.update-content {
  display: flex;
  flex-direction: row;
  align-items: center;
  gap: 8px;
}

.update-content.column-mode {
  flex-direction: column;
  align-items: flex-start;
  gap: 0;
}

.safety-modal-content {
  display: flex;
  align-items: flex-start;
  gap: 12px;
}

.safety-warning-icon {
  font-size: 22px;
  line-height: 1;
  color: var(--text-error);
  margin-top: 2px;
}

.safety-text {
  color: var(--text-base);
  font-size: 14px;
}

.resize-handle {
  width: 3px;
  height: 100%;
  background: transparent;
  cursor: col-resize;
  position: relative;
  flex-shrink: 0;
}

.resize-handle:hover {
  background: var(--color-primary);
  opacity: 0.3;
}

.resize-handle:active {
  background: var(--color-primary);
  opacity: 0.3;
}

</style>

<style>
/* 开发者通道：跳过新手引导按钮 */
.dev-skip-btn {
  position: fixed;
  right: 0;
  bottom: 0;
  width: 50px;
  height: 50px;
  z-index: 100000000;
  cursor: pointer;
}

.driver-overlay, .driver-active * {
  pointer-events: auto;
}

.driver-popover {
  background-color: var(--bg-container);
  color: var(--text-base);
  border-radius: 8px;
  max-width: 500px;
}

.driver-popover .driver-popover-title {
  font-size: 18px;
  font-weight: 600;
  color: var(--text-base);
}

.driver-popover .driver-popover-description {
  font-size: 14px;
  margin-right: 60px;
  word-wrap: normal;
  color: var(--text-base2);
}

.driver-popover .driver-popover-progress-text {
  margin-right: 16px;
  color: var(--text-base2);
}

.driver-popover button {
  text-align: center;
  background-color: var(--color-primary);
  color: var(--text-light);
  border: none !important;
  text-shadow: none;
  font-size: 14px;
  height: fit-content;
  width: fit-content;
  padding: 7px 15px;
  border-radius: 6px;
  transition: all 0.2s;
  outline: none !important;
  cursor: pointer;
}

.driver-popover button:hover {
  background-color: var(--color-hover);
  color: var(--text-light);
  border: none !important;
}

.driver-popover button:focus {
  background-color: var(--color-primary);
  color: var(--text-light);
  border: none !important;
}

.driver-popover .driver-popover-navigation-btns {
  justify-content: flex-end;
  margin-left: auto;
  flex-grow: 0;
  gap: 8px;
}

.skip-btn {
  position: absolute;
  background-color: transparent !important;
  color: var(--text-base2) !important;
  font-size: 13px !important;
  text-align: center;
  padding: 0 1px !important;
  top: 14px;
  right: 18px;
}

.skip-btn:hover {
  color: var(--text-base3) !important;
}

.driver-popover .driver-popover-arrow-side-left.driver-popover-arrow {
  border-left-color: var(--bg-container);
}

.driver-popover .driver-popover-arrow-side-right.driver-popover-arrow {
  border-right-color: var(--bg-container);
}

.driver-popover .driver-popover-arrow-side-top.driver-popover-arrow {
  border-top-color: var(--bg-container);
}

.driver-popover .driver-popover-arrow-side-bottom.driver-popover-arrow {
  border-bottom-color: var(--bg-container);
}
</style>
