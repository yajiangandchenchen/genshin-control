<template>
  <div class="list-container animate-fade-in">
    <a-tree :treeData="filteredTreeData" :expandedKeys="expandedKeys" :selectedKeys="selectedKeys"
      @select="handleSelect" @expand="handleExpand" :block-node="true">
      <template #switcherIcon="{ expanded, dataRef }">
        <span v-if="hasExpandableChildren(dataRef)" class="switcher-icon">
          <CaretDownOutlined v-if="expanded" />
          <CaretRightOutlined v-else />
        </span>
        <span v-else class="empty-switcher"></span>
      </template>
      <template #title="{ title, dataRef }">
        <div class="tree-node-container hover-lift">
          <div class="tree-node-left">
            <a-image v-if="dataRef.showIcon" :src="dataRef.icon" :placeholder="false"
              @error="dataRef.showIcon = false" />
            <span class="tree-node-title-text" v-html="highlightTitle(title)"></span>
            <span v-if="dataRef.hasUpdate" class="has-update-dot"></span>
          </div>
          <a-button class="subscribe-btn" type="text" size="small" @click.stop="handleSubscribe(dataRef)">
            {{ dataRef.isSubscribed ? $t('mapTreeList.subscribeAgain') : $t('mapTreeList.subscribe') }}
          </a-button>
        </div>
      </template>
    </a-tree>
  </div>
</template>

<script setup>
import {computed, onMounted, ref, watch} from 'vue';
import {CaretDownOutlined, CaretRightOutlined} from '@ant-design/icons-vue';
import {useClipboard} from '@vueuse/core';
import {message as Message} from 'ant-design-vue';
import {subscribePaths} from '@/utils/subscription';
import {useI18n} from 'vue-i18n';
import iconUrlMap from '@/assets/icon_url.json';
import {useMainStore} from "@/stores/mainStore.js";
import { findAncestorKeys } from '@/utils/routerHelper.js';
import { highlightText, matchesOrdered, tokenize } from '@/utils/highlight.js';

const { t: $t } = useI18n();

const { copy } = useClipboard();
const mainStore = useMainStore();

const highlightTitle = (title) => {
  return highlightText(title, mainStore.search?.trim());
};

const expandedKeys = ref([]);
const selectedKeys = ref([]);
const treeData = ref([]);

onMounted(() => {
  treeData.value = generateTreeData(mainStore.repoData);
});

watch(() => mainStore.repoData, (val) => {
  treeData.value = generateTreeData(val);
}, { deep: true });

watch(() => mainStore.subscribedScriptPaths, (newPaths) => {
  treeData.value = generateTreeData(mainStore.repoData);
});

// 监听 showSubscribedOnly 变化，重置树展开状态
watch(() => mainStore.scriptTab === 'subscribed', () => {
  expandedKeys.value = [];
  selectedKeys.value = [];
});

// 判断节点是否有可展开的子节点（只允许有子目录的节点可展开，若children全为file则不可展开）
const hasExpandableChildren = (dataRef) => {
  if (!dataRef?.children || dataRef.children.length === 0) return false;
  // 只要有一个子节点是目录即可展开
  return dataRef.children.some(child => child.type === 'directory');
};

// 处理节点展开
const handleExpand = (keys) => {
  expandedKeys.value = keys.filter(key => {
    const node = findNodeByKey(filteredTreeData.value, key);
    return hasExpandableChildren(node);
  });
};

// 处理节点选择
const handleSelect = async (selectedKeysList) => {
  if (selectedKeysList.length === 0) return;
  const selectedNode = findNodeByKey(filteredTreeData.value, selectedKeysList[0]);
  if (!selectedNode) return;

  // 如果有搜索关键词，需要过滤 files 和 authors
  let nodeToSelect = selectedNode;
  if (mainStore.search && mainStore.search.trim() && selectedNode.files && Array.isArray(selectedNode.files)) {
    const keyword = mainStore.search.trim().toLowerCase();
    
    // 对文件进行评分和过滤
    const scoreFile = (file) => {
      const tokens = tokenize(keyword, s => s);
      const match = tokens.length === 1
        ? (text) => text.includes(tokens[0])
        : (text) => matchesOrdered(text, tokens);

      let isExact = tokens.length === 1 && (
        (file.name && file.name.toLowerCase() === keyword) ||
        (file.authors && file.authors.some(a => normalize(a.name) === keyword)) ||
        ((file.tags || []).some(tag => tag.toLowerCase() === keyword)) ||
        (file.description && file.description.toLowerCase() === keyword)
      );

      let score = 0;
      if (file.name && match(file.name.toLowerCase())) score += 3;
      if (file.authors && file.authors.some(a => match(normalize(a.name)))) score += 3;
      if ((file.tags || []).some(tag => match(tag.toLowerCase()))) score += 2;
      if (file.description && match(file.description.toLowerCase())) score += 2;
      return isExact || score > 0;
    };
    
    // 过滤 files 数组
    const filteredFiles = selectedNode.files.filter(file => scoreFile(file));
    
    // 重新收集筛选后文件的作者
    const collectAuthorsFromFiles = (files) => {
      const authorsMap = new Map();
      files.forEach(file => {
        if (Array.isArray(file.authors)) {
          file.authors.forEach(author => {
            if (author && author.name) {
              authorsMap.set(author.name, author);
            }
          });
        }
      });
      return Array.from(authorsMap.values());
    };
    
    const filteredAuthors = collectAuthorsFromFiles(filteredFiles);
    nodeToSelect = { ...selectedNode, files: filteredFiles, authors: filteredAuthors };
  }

  // 使用mainStore的方法选择节点
  mainStore.handleMapSelect(nodeToSelect);
  selectedKeys.value = selectedNode.key ? [selectedNode.key] : [];

  if (selectedNode.hasUpdate && mainStore.isModeSingle) {
    const repoWebBridge = chrome.webview.hostObjects.repoWebBridge;
    const result = await repoWebBridge.UpdateSubscribed(selectedNode.path);
    if (result) {
      // 使用mainStore的方法更新hasUpdate状态
      mainStore.updateScriptHasUpdate(selectedNode.path, false);
    } else {
      console.error('Failed to update subscription:');
    }
  }

  console.log("Node selected", nodeToSelect);
};

// 处理订阅
const handleSubscribe = async (nodeData) => {
  if (!nodeData || !nodeData.key) {
    Message.error($t('mapTreeList.selectValidNode'));
    return;
  }
  try {
    await handleSelect([nodeData.key]);
    const result = await subscribePaths([nodeData.path]);
    if (result.needsCopy) {
      await copy(result.url);
      Message.success($t('mapTreeList.subscribeSuccess', { name: nodeData.name }));
    } else {
      mainStore.startPollingUserConfig();
    }
  } catch (error) {
    console.error('Subscribe failed:', error);
    Message.error($t('mapTreeList.subscribeFailedWithMsg', { msg: error.message }));
  }
};

// 查找节点
const findNodeByKey = (nodes, key) => {
  if (!nodes) return null;

  const stack = [...nodes];
  while (stack.length) {
    const node = stack.pop();
    if (node.key === key) return node;
    if (node.children) stack.push(...node.children);
  }
  return null;
};

// 递归收集所有 file 节点，并补全 path 字段
function collectFiles(node, parentPath = '') {
  let files = [];
  if (node.type === 'file') {
    // 生成与订阅时完全一致的路径格式
    const fullPath = parentPath ? `${parentPath}/${node.name}` : node.name;
    files.push({ ...node, path: `pathing/${fullPath}` });
  } else if (node.children) {
    node.children.forEach(child => {
      const childParentPath = parentPath ? `${parentPath}/${node.name}` : node.name;
      files = files.concat(collectFiles(child, childParentPath));
    });
  }
  return files;
}

// 递归收集authors
function collectAuthors(node) {
  let authors = [];

  // 收集当前节点的作者
  if (Array.isArray(node.authors)) {
    authors = [...node.authors];
  }

  // 收集子节点的作者
  if (Array.isArray(node.children)) {
    const childAuthors = node.children.flatMap(collectAuthors);
    authors.push(...childAuthors);
  }

  // 去重
  return Array.from(
      new Map(authors.filter(a => a && a.name).map(a => [a.name, a])).values()
  );
}

// 递归给 files 节点赋 isSubscribed 字段
function markFilesSubscribed(files, subscribedPaths) {
  if (!Array.isArray(files)) return [];
  return files.map(file => ({
    ...file,
    isSubscribed: subscribedPaths.some(sub => file.path && file.path.startsWith(sub))
  }));
}

// 获取最新更新时间
const getLatestUpdateTime = (files) => {
  if (!Array.isArray(files) || files.length === 0) return '';
  return files.reduce((latest, f) => {
    return (!latest || new Date(f.lastUpdated) > new Date(latest)) ? f.lastUpdated : latest;
  }, '');
};

// 国家图标仅用于地方特产直接子目录下
const countries = ["蒙德", "璃月", "稻妻", "须弥", "枫丹", "纳塔", "挪德卡莱", "至冬"];
const countriesParentNode = "地方特产";
import liniaIcon from "@/assets/roles_icon/莉奈娅.webp";

// 处理节点数据
const processNode = (node, parentKey = '', parentSubscribed = false) => {
  const currentKey = parentKey ? `${parentKey}/${node.name}` : node.name;
  // 先判断自身是否订阅
  const selfSubscribed = mainStore.subscribedScriptPaths.some(sub => (`pathing/${currentKey}`).startsWith(sub));
  // 如果父节点已订阅，自己也视为已订阅
  const isSubscribed = parentSubscribed || selfSubscribed;
  const children = node.children?.map(child => processNode(child, currentKey, isSubscribed)) || [];
  let iconPath = '';
  let showIcon = node.showIcon || false;
  // 添加图标路径
  if (node.children && node.children.length > 0) {
    const mappedItem = Array.isArray(iconUrlMap) ? iconUrlMap.find(item => item && item.name === node.name) : undefined;
    if (mappedItem && mappedItem.link) {
      iconPath = mappedItem.link;
      showIcon = true;
    }
    if (countries.some(country => node.name.includes(country)) && !currentKey.includes(countriesParentNode)) {
      iconPath = '';
      showIcon = false;
    }
    if (node.name.includes('莉奈娅')) {
      iconPath = liniaIcon;
      showIcon = true;
    }
  }
  let files = [];
  let lastUpdated = '';
  if (node.type === 'directory') {
    // 传递父级路径，不包含当前目录名
    files = collectFiles(node, parentKey);
    files = markFilesSubscribed(files, mainStore.subscribedScriptPaths);
    // 目录显示最新文件时间
    lastUpdated = getLatestUpdateTime(files);
  } else if (node.type === 'file') {
    // 文件显示自身时间
    lastUpdated = node.lastUpdated || '';
  }

  const authors = collectAuthors(node);

  return {
    key: currentKey,
    title: node.name,
    name: node.name,
    type: node.type || '',
    version: node.version,
    authors: authors,
    description: node.description,
    tags: node.tags || [],
    lastUpdated: lastUpdated,
    children,
    icon: iconPath,
    showIcon: showIcon,
    path: `pathing/${currentKey}`,
    files,
    isSubscribed,
    hasUpdate: node.hasUpdate || false,
  };
};

// 生成树形数据
const generateTreeData = (data) => {
  if (!data?.indexes) return [];

  const mapCategory = data.indexes.find(c => c.name === 'pathing');
  return mapCategory?.children?.map(node => processNode(node, '', false)) || [];
};

// 获取匹配数据
const filteredTreeData = computed(() => {
  // 递归过滤并加分
  function scoreNode(node, keyword) {
    const tokens = tokenize(keyword, s => s);
    const match = tokens.length === 1
      ? (text) => text.includes(tokens[0])
      : (text) => matchesOrdered(text, tokens);

    let isExact = tokens.length === 1 && (
      (node.title && node.title.toLowerCase() === keyword) ||
      (node.authors && node.authors.some(a => normalize(a.name) === keyword)) ||
      ((node.tags || []).some(tag => tag.toLowerCase() === keyword)) ||
      (node.description && node.description.toLowerCase() === keyword)
    );
    let score = 0;
    if (node.title && match(node.title.toLowerCase())) score += 3;
    if (node.authors && node.authors.some(a => match(normalize(a.name)))) score += 3;
    if ((node.tags || []).some(tag => match(tag.toLowerCase()))) score += 2;
    if (node.description && match(node.description.toLowerCase())) score += 2;
    return { ...node, _isExact: isExact, _score: score };
  }

  // 筛选并为节点计算权重
  function filterAndScore(nodes, keyword) {
    let result = [];
    for (const node of nodes) {
      if (node.children && node.children.length) {
        const children = filterAndScore(node.children, keyword);
        if (children.length) {
          result.push({ ...scoreNode(node, keyword), children });
        }
      } else {
        const scored = scoreNode(node, keyword);
        if (scored._isExact || scored._score > 0) {
          result.push(scored);
        }
      }
    }
    return result;
  }

  // 展平所有叶子节点，分为exact和others
  function flatten(nodes, arr = []) {
    for (const node of nodes) {
      if (node.children && node.children.length) {
        flatten(node.children, arr);
      } else {
        arr.push(node);
      }
    }
    return arr;
  }

  // 只保留有相关叶子的分支
  function filterByLeaf(nodes, leafSet) {
    let result = [];
    for (const node of nodes) {
      if (node.children && node.children.length) {
        const children = filterByLeaf(node.children, leafSet);
        if (children.length) {
          result.push({ ...node, children });
        }
      } else if (leafSet.has(node)) {
        result.push(node);
      }
    }
    return result;
  }

  // 只显示已订阅
  if (mainStore.scriptTab === 'subscribed') {
    if (!mainStore.subscribedScriptPaths || mainStore.subscribedScriptPaths.length === 0) {
      return [];
    }
    const pathingSubs = mainStore.subscribedScriptPaths.filter(p => p.startsWith('pathing/'));
    function filterTreeBySubscribedPaths(nodes, subscribedPaths) {
      if (!nodes) return [];
      return nodes.map(node => {
        const isSubscribed = subscribedPaths.some(sub => node.path.startsWith(sub));
        if (isSubscribed) {
          return {
            ...node,
            children: node.children ? filterTreeBySubscribedPaths(node.children, subscribedPaths) : []
          };
        }
        if (node.children) {
          const filteredChildren = filterTreeBySubscribedPaths(node.children, subscribedPaths);
          if (filteredChildren.length > 0) {
            return { ...node, children: filteredChildren };
          }
        }
        return null;
      }).filter(Boolean);
    }
    // 只在已订阅节点中做搜索
    let baseTree = filterTreeBySubscribedPaths(treeData.value, pathingSubs);
    if (!mainStore.search) return baseTree;
    // 搜索框输入
    const keyword = mainStore.search.trim().toLowerCase();
    let filtered = filterAndScore(baseTree, keyword);

    const allLeaf = flatten(filtered);
    const exactLeaf = allLeaf.filter(n => n._isExact);
    const otherLeaf = allLeaf.filter(n => !n._isExact && n._score > 0);
    otherLeaf.sort((a, b) => (b._score || 0) - (a._score || 0));
    const allMatched = [...exactLeaf, ...otherLeaf];
    if (allMatched.length) {
      const leafSet = new Set(allMatched);
      return filterByLeaf(filtered, leafSet);
    } else {
      return [];
    }
  } else {
    if (!mainStore.search) return treeData.value;
    // 搜索框输入
    const keyword = mainStore.search.trim().toLowerCase();
    let filtered = filterAndScore(treeData.value, keyword);

    const allLeaf = flatten(filtered);
    const exactLeaf = allLeaf.filter(n => n._isExact);
    const otherLeaf = allLeaf.filter(n => !n._isExact && n._score > 0);
    otherLeaf.sort((a, b) => (b._score || 0) - (a._score || 0));

    const allMatched = [...exactLeaf, ...otherLeaf];
    if (allMatched.length) {
      const leafSet = new Set(allMatched);
      return filterByLeaf(filtered, leafSet);
    } else {
      return [];
    }
  }
});

const updateExpandedKeysForSearch = (newSearchKey) => {
  if (!newSearchKey) {
    expandedKeys.value = [];
    return;
  }
  // 递归收集所有叶子节点及其路径
  function collectMatchedLeafKeys(nodes, path = [], result = []) {
    for (const node of nodes) {
      if (node.children && node.children.length) {
        collectMatchedLeafKeys(node.children, [...path, node], result);
      } else {
        result.push({ node, path });
      }
    }
    return result;
  }
  const matchedLeafs = collectMatchedLeafKeys(filteredTreeData.value);
  const expandedSet = new Set();
  matchedLeafs.forEach(({ path }) => {
    path.forEach(parentNode => {
      if (hasExpandableChildren(parentNode)) {
        expandedSet.add(parentNode.key);
      }
    });
  });
  expandedKeys.value = [...expandedSet];
}

watch(
  () => mainStore.search,
  (newSearchKey) => {
    updateExpandedKeysForSearch(newSearchKey);
  }
);

function normalize(str) {
  return (str || '').toLowerCase().replace(/[\s【】\[\]（）()·,，.。!！?？\-_]/g, '');
}

// 通过路径 key 展开树并选中节点
async function navigateTo(targetKey) {
  const targetNode = findNodeByKey(treeData.value, targetKey);
  if (!targetNode) return false;

  const ancestorKeys = findAncestorKeys(treeData.value, targetKey);
  if (!ancestorKeys) return false;

  // 只展开 directory 类型的祖先
  expandedKeys.value = ancestorKeys.filter((key) => {
    const node = findNodeByKey(treeData.value, key);
    return node && hasExpandableChildren(node);
  });
  selectedKeys.value = [targetKey];

  mainStore.handleMapSelect(targetNode);
  return true;
}

defineExpose({ navigateTo });

</script>

<style scoped>
.list-container {
  width: 100%;
  height: 100%;
  overflow-y: auto;
  overflow-x: hidden;
  padding: 4px 0 4px 0;
  scrollbar-gutter: stable both-edges;
}

.tree-node-container {
  display: flex;
  align-items: center;
  width: 100%;
  transition: background-color 0.3s var(--ease-in-out), transform 0.3s var(--ease-in-out), color 0.3s var(--ease-in-out);
  padding: 2px 4px;
}

.tree-node-container:hover {
  transform: translateX(4px);
  border: none !important;
  box-shadow: none !important;
}

.tree-node-left {
  display: flex;
  align-content: center;
  align-items: center;
}

.empty-switcher {
  display: inline-block;
  width: 24px;
}

.switcher-icon {
  transition: transform 0.3s var(--ease-in-out);
}

:deep(.ant-image) {
  align-content: center;
  justify-content: center;
  transition: transform 0.3s var(--ease-in-out);
}

:deep(.ant-image):hover {
  transform: scale(1.1);
}

:deep(.ant-image-img) {
  width: 26px;
  height: 26px;
  border-radius: 10px;
  transition: all 0.3s var(--ease-in-out);
}

.tree-node-title-text {
  flex: 1;
  font-size: 14px;
  margin: 0 5px 0 2px;
  transition: color 0.3s var(--ease-in-out);
}

.tree-node-title-text :deep(mark) {
  background: yellow;
  color: black;
  padding: 0;
  border-radius: 2px;
}

.tree-node-container:hover .tree-node-title-text {
  color: var(--color-primary);
}

.subscribe-btn {
  margin-left: auto;
  background: none;
  border: none;
  width: 72px;
  text-align: center;
  color: var(--color-primary);
  transition: all 0.3s var(--ease-in-out);
  border-radius: 4px;
  padding: 2px 8px;
  flex-shrink: 0;
}

.subscribe-btn:hover {
  transform: scale(1.05);
}

:deep(.ant-tree) {
  width: calc(100% - 10px);
  background: var(--bg-menu);
  backdrop-filter: blur(5px);
}

:deep(.ant-tree-treenode) {
  width: 100%;
  padding: 5px;
}

/* 禁用 Ant Design Tree 默认的展开动画，避免自定义动画闪烁 */
:deep(.ant-tree-treenode) {
  transition: none;
}

:deep(.ant-tree .ant-tree-node-content-wrapper.ant-tree-node-selected) {
  background: var(--bg-item-selected);
  transition: background-color 0.3s var(--ease-in-out);
  border: none !important;
  box-shadow: none !important;
}

:deep(.ant-tree .ant-tree-node-content-wrapper) {
  transition: background-color 0.3s var(--ease-in-out);
  border: none !important;
  box-shadow: none !important;
}

:deep(.ant-tree .ant-tree-node-content-wrapper:hover) {
  border: none !important;
  box-shadow: none !important;
}

:deep(.ant-tree-switcher) {
  transition: transform 0.3s var(--ease-in-out);
  align-self: center;
}

.subscribe-btn[disabled] {
  cursor: default !important;
  opacity: 0.6;
}

.has-update-dot {
  display: inline-block;
  width: 6px;
  height: 6px;
  background: var(--color-update);
  border-radius: 50%;
  margin-left: 6px;
  vertical-align: middle;
  align-self: center;
  animation: pulse 2s infinite;
}

:deep(.ant-tree-treenode) {
  transition: all 0.3s var(--ease-in-out);
}

:deep(.ant-tree-icon-switcher-leaf-line) {
  transition: all 0.3s var(--ease-in-out);
}
</style>